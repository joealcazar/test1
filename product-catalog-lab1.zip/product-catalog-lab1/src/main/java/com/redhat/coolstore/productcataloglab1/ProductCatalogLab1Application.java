package com.redhat.coolstore.productcataloglab1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCatalogLab1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCatalogLab1Application.class, args);
	}

}
